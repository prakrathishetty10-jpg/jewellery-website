const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');

// Hardcoded admin credentials (for now)
const ADMIN_USERNAME = 'admin';
const ADMIN_PASSWORD = 'admin123';
const ADMIN_SECRET = 'supersecretadminkey'; // JWT secret

// ----- ADMIN LOGIN -----
router.post('/login', (req, res) => {
    const { username, password } = req.body;
    if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
        // Generate JWT token
        const token = jwt.sign({ username }, ADMIN_SECRET, { expiresIn: '8h' });
        return res.json({ success: true, message: "Admin login successful", token });
    }
    res.status(401).json({ success: false, message: "Invalid admin credentials" });
});

// ----- MIDDLEWARE: VERIFY ADMIN -----
function verifyAdmin(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1]; // Expect Bearer TOKEN
    if (!token) return res.status(401).json({ message: "Access denied. No token provided." });

    try {
        const decoded = jwt.verify(token, ADMIN_SECRET);
        req.admin = decoded;
        next();
    } catch (err) {
        return res.status(403).json({ message: "Invalid token" });
    }
}

module.exports = { adminRouter: router, verifyAdmin };
