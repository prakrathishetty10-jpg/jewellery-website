const express = require('express');
const router = express.Router();
const Order = require('../models/Order');
const { verifyAdmin } = require('./admin');

// ----- GET ALL ORDERS (ADMIN) -----
router.get('/admin/orders', verifyAdmin, async (req, res) => {
    try {
        const orders = await Order.find();
        res.json(orders);
    } catch(err) {
        console.error(err);
        res.status(500).json({ message: "Server error" });
    }
});

// ----- CREATE ORDER -----
router.post('/create-order', async (req, res) => {
    const { user, items, amount, paymentMethod } = req.body;
    if(!items || !items.length || !amount) return res.status(400).json({ message: "Invalid order data" });

    try {
        const newOrder = new Order({ user, items, amount, paymentMethod });
        await newOrder.save();
        res.json({ message: "Order created", order: newOrder });
    } catch(err) {
        console.error(err);
        res.status(500).json({ message: "Server error" });
    }
});

// ----- UPDATE ORDER STATUS (ADMIN) -----
router.post('/admin/update-order', verifyAdmin, async (req, res) => {
    const { orderId, status } = req.body;
    if(!orderId || !status) return res.status(400).json({ message: "Order ID and status required" });

    try {
        const order = await Order.findById(orderId);
        if(!order) return res.status(404).json({ message: "Order not found" });

        order.orderStatus = status;
        await order.save();
        res.json({ success: true, message: "Order updated" });
    } catch(err) {
        console.error(err);
        res.status(500).json({ message: "Server error" });
    }
});

module.exports = router;
