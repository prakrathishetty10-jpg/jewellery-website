const express = require('express');
const router = express.Router();
const Product = require('../models/Product');

// GET all products
router.get('/products', async (req, res) => {
  try {
    const products = await Product.find();
    res.json(products);
  } catch(err) {
    res.status(500).json({ message: "Failed to fetch products" });
  }
});

// POST add new product
router.post('/products', async (req, res) => {
  const { title, price, oldPrice, stock, category, images, description } = req.body;
  if (!title || !price || !stock || !category || !images || !images.length)
    return res.status(400).json({ message: "Missing required fields or images" });

  try {
    const newProduct = new Product({ title, price, oldPrice, stock, category, images, description });
    await newProduct.save();
    res.status(201).json({ success: true, product: newProduct });
  } catch(err) {
    console.error(err);
    res.status(500).json({ message: "Failed to save product" });
  }
});

// PUT update product
router.put('/products/:id', async (req, res) => {
  const { title, price, oldPrice, stock, category, images, description } = req.body;
  if (!title || !price || !stock || !category || !images || !images.length)
    return res.status(400).json({ message: "Missing required fields or images" });

  try {
    const updatedProduct = await Product.findByIdAndUpdate(
      req.params.id,
      { title, price, oldPrice, stock, category, images, description },
      { new: true }
    );
    if(!updatedProduct) return res.status(404).json({ message: "Product not found" });
    res.json({ success: true, product: updatedProduct });
  } catch(err) {
    console.error(err);
    res.status(500).json({ message: "Failed to update product" });
  }
});

// DELETE product
router.delete('/products/:id', async (req, res) => {
  try {
    await Product.findByIdAndDelete(req.params.id);
    res.json({ success: true, message: "Deleted" });
  } catch(err) {
    res.status(500).json({ message: "Failed to delete product" });
  }
});

module.exports = router;
