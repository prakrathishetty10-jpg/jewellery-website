const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const User = require('../models/User');

// ----- REGISTER USER -----
router.post('/register', async (req, res) => {
    const { username, email, password } = req.body;
    if (!username || !email || !password) 
        return res.status(400).json({ success: false, message: "All fields are required" });

    try {
        const exists = await User.findOne({ $or: [{ username }, { email }] });
        if (exists) 
            return res.status(400).json({ success: false, message: "Username or Email already exists" });

        const hashed = await bcrypt.hash(password, 10);
        const user = new User({ username, email, password: hashed });
        await user.save();

        res.json({ success: true, message: "User registered successfully" });
    } catch(err) {
        console.error("User registration error:", err);
        res.status(500).json({ success: false, message: "Server error" });
    }
});

module.exports = router;
