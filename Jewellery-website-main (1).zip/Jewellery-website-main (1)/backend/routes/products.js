const express = require('express');
const router = express.Router();
const Product = require('../models/Product');
const { verifyAdmin } = require('./adminRoutes');


// ---------------------------
// 📌 PUBLIC ROUTES (Frontend)
// ---------------------------

// Get ALL products (public)
router.get('/', async (req, res) => {
    try {
        const products = await Product.find();
        res.json(products);
    } catch (err) {
        res.status(500).json({ message: "Failed to fetch products", error: err.message });
    }
});

// Get products by category (public)
router.get('/category/:category', async (req, res) => {
    try {
        const cat = req.params.category;

        // Case-insensitive flexible search
        const products = await Product.find({
            category: { $regex: new RegExp(cat, "i") }  
        });

        res.json(products);
    } catch (err) {
        res.status(500).json({ message: "Failed to fetch category products", error: err.message });
    }
});


// ---------------------------
// 📌 ADMIN ROUTES (Protected)
// ---------------------------

// Create new product (Admin)
router.post('/', verifyAdmin, async (req, res) => {
    const { title, sku, price, stock, category, image } = req.body;
    if (!title || !price) return res.status(400).json({ message: "Title and price are required" });

    try {
        const product = new Product({ title, sku, price, stock, category, image });
        await product.save();
        res.json({ success: true, message: "Product added", product });
    } catch (err) {
        res.status(500).json({ message: "Failed to add product", error: err.message });
    }
});

// Update product (Admin)
router.put('/:id', verifyAdmin, async (req, res) => {
    const { id } = req.params;
    const { title, sku, price, stock, category, image } = req.body;

    try {
        const product = await Product.findByIdAndUpdate(
            id,
            { title, sku, price, stock, category, image },
            { new: true }
        );
        if (!product) return res.status(404).json({ message: "Product not found" });
        res.json({ success: true, message: "Product updated", product });
    } catch (err) {
        res.status(500).json({ message: "Failed to update product", error: err.message });
    }
});

// Delete product (Admin)
router.delete('/:id', verifyAdmin, async (req, res) => {
    const { id } = req.params;

    try {
        const product = await Product.findByIdAndDelete(id);
        if (!product) return res.status(404).json({ message: "Product not found" });
        res.json({ success: true, message: "Product deleted" });
    } catch (err) {
        res.status(500).json({ message: "Failed to delete product", error: err.message });
    }
});


module.exports = router;
