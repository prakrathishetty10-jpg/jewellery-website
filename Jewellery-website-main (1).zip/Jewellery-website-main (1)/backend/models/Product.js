const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  title: { type: String, required: true },
  price: { type: Number, required: true },
  oldPrice: { type: Number, default: 0 },
  stock: { type: Number, default: 0 },
  category: { type: String, required: true },
  images: { type: [String], default: [] }, // ← allow multiple images
  description: { type: String }
}, { timestamps: true });

module.exports = mongoose.model('Product', productSchema);
