const mongoose = require("mongoose");

// Connect to DB
mongoose.connect("mongodb://127.0.0.1:27017/jewelleryDB")
  .then(() => console.log("MongoDB connected"))
  .catch(err => console.error(err));

// Define Schemas
const productSchema = new mongoose.Schema({
  title: String, sku: String, price: Number, stock: Number, category: String, image: String
});
const userSchema = new mongoose.Schema({
  username: String, email: String, password: String
});
const orderSchema = new mongoose.Schema({
  user: String, items: Array, total: Number, paid: Boolean, status: String
});

const Product = mongoose.model("Product", productSchema);
const User = mongoose.model("User", userSchema);
const Order = mongoose.model("Order", orderSchema);

async function seed() {
  await Product.deleteMany({});
  await User.deleteMany({});
  await Order.deleteMany({});

  await Product.insertMany([
    { title: "Gold Ring", sku: "GR01", price: 1999, stock: 10, category: "Rings", image: "" },
    { title: "Silver Necklace", sku: "SN01", price: 2499, stock: 5, category: "Necklaces", image: "" }
  ]);

  await User.insertMany([
    { username: "Alice", email: "alice@gmail.com", password: "mite" },
    { username: "Bob", email: "bob@gmail.com", password: "mite" }
  ]);

  await Order.insertMany([
    { user: "Alice", items: [{ title: "Gold Ring", qty: 1, price: 1999 }], total: 1999, paid: true, status: "Delivered" }
  ]);

  console.log("Database seeded!");
  mongoose.disconnect();
}

seed();
