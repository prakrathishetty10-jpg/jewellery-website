// ================== server.js ==================
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const bcrypt = require("bcrypt");

const app = express();
const PORT = 3000;

// ------------------- MIDDLEWARE -------------------
app.use(cors());
app.use(express.json());
app.use(express.static("public")); // serve frontend files

// ------------------- MONGODB CONNECTION -------------------
mongoose.connect("mongodb://127.0.0.1:27017/jewelleryDB")
  .then(() => console.log("MongoDB connected"))
  .catch(err => console.error("MongoDB connection error:", err));

// ------------------- SCHEMAS -------------------
const userSchema = new mongoose.Schema({
  username: String,
  email: String,
  password: String
});

const productSchema = new mongoose.Schema({
  title: String,
  price: Number,
  oldPrice: Number,
  stock: Number,
  category: String,
  image: String,
  description: String, // Important
});

const orderSchema = new mongoose.Schema({
  user: String,
  items: Array,
  total: Number,
  paid: Boolean,
  status: String
});


// ------------------- MODELS -------------------
const User = mongoose.model("User", userSchema);
const Product = mongoose.model("Product", productSchema);
const Order = mongoose.model("Order", orderSchema);

// ===================== USER ROUTES =====================

// REGISTER USER
app.post("/api/register", async (req, res) => {
  try {
    const { username, email, password } = req.body;
    if (!username || !email || !password)
      return res.json({ success: false, message: "All fields required" });

    const exist = await User.findOne({ email });
    if (exist)
      return res.json({ success: false, message: "Email already exists" });

    const hashedPassword = await bcrypt.hash(password, 10);
    const user = new User({ username, email, password: hashedPassword });
    await user.save();

    res.json({ success: true, message: "User registered successfully" });
  } catch (err) {
    console.error(err);
    res.json({ success: false, message: "Server error" });
  }
});

// LOGIN USER
app.post("/api/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.json({ success: false, message: "Invalid login details" });

    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.json({ success: false, message: "Invalid login details" });

    res.json({ success: true, message: "Login successful", user });
  } catch (err) {
    console.error(err);
    res.json({ success: false, message: "Server error" });
  }
});

// ===================== ADMIN ROUTES =====================

// GET ALL USERS
app.get("/api/admin/users", async (req, res) => {
  try {
    const users = await User.find();
    res.json(users);
  } catch (err) {
    console.error(err);
    res.status(500).json([]);
  }
});

// DELETE USER
app.delete("/api/admin/users/:id", async (req, res) => {
  try {
    await User.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.json({ success: false });
  }
});

// ------------------- PRODUCTS ROUTES (ADMIN) -------------------

// GET ALL PRODUCTS
app.get("/api/admin/products", async (req, res) => {
  try {
    const products = await Product.find();
    res.json(products);
  } catch (err) {
    console.error(err);
    res.json([]);
  }
});

// ADD PRODUCT
app.post("/api/admin/products", async (req, res) => {
  try {
    const { title, price, oldPrice, stock, category, image, description } = req.body;
    const product = new Product({ title, price, oldPrice, stock, category, image, description });
    await product.save();
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.json({ success: false });
  }
});

// DELETE PRODUCT
app.delete("/api/admin/products/:id", async (req, res) => {
  try {
    await Product.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.json({ success: false });
  }
});

// EDIT / UPDATE PRODUCT
app.put("/api/admin/products/:id", async (req, res) => {
  try {
    const { title, price, oldPrice, stock, category, image, description } = req.body;
    const updatedProduct = await Product.findByIdAndUpdate(
      req.params.id,
      { title, price, oldPrice, stock, category, image, description }, // ✅ include description
      { new: true }
    );
    if (!updatedProduct)
      return res.json({ success: false, message: "Product not found" });
    res.json({ success: true, message: "Product updated", product: updatedProduct });
  } catch (err) {
    console.error(err);
    res.json({ success: false, message: "Server error" });
  }
});

// ------------------- PUBLIC PRODUCTS ROUTE -------------------
app.get("/api/public/products", async (req, res) => {
  try {
    const products = await Product.find();
    res.json(products); // visible for front-end
  } catch (err) {
    console.error(err);
    res.json([]);
  }
});

// ------------------- ORDERS ROUTES -------------------
app.get("/api/admin/orders", async (req, res) => {
  try {
    const orders = await Order.find();
    res.json(orders);
  } catch (err) {
    console.error(err);
    res.json([]);
  }
});

// DELETE ORDER
app.delete("/api/admin/orders/:id", async (req, res) => {
  try {
    await Order.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.json({ success: false });
  }
});

// ==================== SERVER RUN =====================
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
