const Admin = require("../models/admin");
const bcrypt = require("bcrypt");

const products = []; // Temporary product storage

// Show register page
exports.registerPage = (req, res) => {
  res.render("admin-register");
};

// Register admin
exports.register = async (req, res) => {
  const { username, email, password } = req.body;

  const existingAdmin = await Admin.findOne({ email });
  if (existingAdmin) {
    return res.render("admin-register", { error: "Email already exists" });
  }

  const hashedPassword = await bcrypt.hash(password, 10);

  await Admin.create({
    username,
    email,
    password: hashedPassword,
  });

  res.redirect("/admin/login");
};

// Login Page
exports.loginPage = (req, res) => {
  res.render("admin-login");
};

// Login verify
exports.login = async (req, res) => {
  const { email, password } = req.body;

  const admin = await Admin.findOne({ email });
  if (!admin) {
    return res.render("admin-login", { error: "Admin not found" });
  }

  const match = await bcrypt.compare(password, admin.password);
  if (!match) {
    return res.render("admin-login", { error: "Incorrect password" });
  }

  req.session.admin = admin;
  res.redirect("/admin/dashboard");
};

// Dashboard

exports.dashboard = (req, res) => {
  if (!req.session.admin) return res.redirect("/admin/login");

  res.render("admin-dashboard", { 
    admin: req.session.admin,       // send admin session
    totalProducts: products.length,
    totalOrders: 0,                 // temporary (you can update later)
    paidOrders: 0
  });
};


