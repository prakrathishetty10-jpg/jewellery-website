// ============================================================
// COMPLETE CART SYSTEM - Replace your existing cart code with this
// ============================================================

(function ($) {
  "use strict";

  new WOW().init();

  //navbar cart
  $(".cart_link > a").on("click", function (e) {
    e.preventDefault();
    $(".mini_cart").addClass("active");
  });

  $(".mini_cart_close > a, #closeMiniCart").on("click", function (e) {
    e.preventDefault();
    $(".mini_cart").removeClass("active");
  });

  //sticky navbar
  $(window).on("scroll", function () {
    var scroll = $(window).scrollTop();
    if (scroll < 100) {
      $(".sticky-header").removeClass("sticky");
    } else {
      $(".sticky-header").addClass("sticky");
    }
  });

  // background image
  function dataBackgroundImage() {
    $("[data-bgimg]").each(function () {
      var bgImgUrl = $(this).data("bgimg");
      $(this).css({
        "background-image": "url(" + bgImgUrl + ")",
      });
    });
  }

  $(window).on("load", function () {
    dataBackgroundImage();
  });

  //for carousel slider
  $(".slider_area").owlCarousel({
    animateOut: "fadeOut",
    autoplay: true,
    loop: true,
    nav: false,
    autoplayTimeout: 6000,
    items: 1,
    dots: true,
  });

  //product column responsive
  $(".product_column3").slick({
    centerMode: true,
    centerPadding: "0",
    slidesToShow: 5,
    arrows: true,
    rows: 2,
    prevArrow: '<button class="prev_arrow"><i class="ion-chevron-left"></i></button>',
    nextArrow: '<button class="next_arrow"><i class="ion-chevron-right"></i></button>',
    responsive: [
      { breakpoint: 400, settings: { slidesToShow: 1, slidesToScroll: 1 } },
      { breakpoint: 768, settings: { slidesToShow: 2, slidesToScroll: 2 } },
      { breakpoint: 992, settings: { slidesToShow: 3, slidesToScroll: 3 } },
      { breakpoint: 1200, settings: { slidesToShow: 4, slidesToScroll: 4 } }
    ],
  });

  //for tooltip
  $('[data-toggle="tooltip"]').tooltip();
  $(".action_links ul li a, .quick_button a").tooltip({
    animated: "fade",
    placement: "top",
    container: "body",
  });

  //product row activation
  $(".product_row1").slick({
    centerMode: true,
    centerPadding: "0",
    slidesToShow: 5,
    arrows: true,
    prevArrow: '<button class="prev_arrow"><i class="ion-chevron-left"></i></button>',
    nextArrow: '<button class="next_arrow"><i class="ion-chevron-right"></i></button>',
    responsive: [
      { breakpoint: 400, settings: { slidesToShow: 1, slidesToScroll: 1 } },
      { breakpoint: 768, settings: { slidesToShow: 2, slidesToScroll: 2 } },
      { breakpoint: 992, settings: { slidesToShow: 3, slidesToScroll: 3 } },
      { breakpoint: 1200, settings: { slidesToShow: 4, slidesToScroll: 4 } }
    ],
  });

  // blog section
  $(".blog_column3").owlCarousel({
    autoplay: true,
    loop: true,
    nav: true,
    autoplayTimeout: 5000,
    items: 3,
    dots: false,
    margin: 30,
    navText: ['<i class="ion-chevron-left"></i>', '<i class="ion-chevron-right"></i>'],
    responsiveClass: true,
    responsive: {
      0: { items: 1 },
      768: { items: 2 },
      992: { items: 3 }
    },
  });

  //navactive responsive
  $(".product_navactive").owlCarousel({
    autoplay: false,
    loop: true,
    nav: true,
    items: 4,
    dots: false,
    navText: ['<i class="ion-chevron-left arrow-left"></i>', '<i class="ion-chevron-right arrow-right"></i>'],
    responsiveClass: true,
    responsive: {
      0: { items: 1 },
      250: { items: 2 },
      480: { items: 3 },
      768: { items: 4 }
    },
  });

  $(".modal").on("shown.bs.modal", function (e) {
    $(".product_navactive").resize();
  });

  $(".product_navactive a").on("click", function (e) {
    e.preventDefault();
    var $href = $(this).attr("href");
    $(".product_navactive a").removeClass("active");
    $(this).addClass("active");
    $(".product-details-large .tab-pane").removeClass("active show");
    $(".product-details-large " + $href).addClass("active show");
  });

})(jQuery);

// ============================================================
// CART & WISHLIST SYSTEM - Single source of truth
// ============================================================

const CartSystem = {
  STORAGE_KEY: 'harshaGoldCart',
  WISHLIST_KEY: 'harshaGoldWishlist',

  // Get cart from localStorage
  getCart() {
    const cart = localStorage.getItem(this.STORAGE_KEY);
    return cart ? JSON.parse(cart) : [];
  },

  // Save cart to localStorage
  saveCart(cart) {
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(cart));
  },

  // Get wishlist from localStorage
  getWishlist() {
    const wishlist = localStorage.getItem(this.WISHLIST_KEY);
    return wishlist ? JSON.parse(wishlist) : [];
  },

  // Save wishlist to localStorage
  saveWishlist(wishlist) {
    localStorage.setItem(this.WISHLIST_KEY, JSON.stringify(wishlist));
  },

  // Add item to wishlist
  addToWishlist(product) {
    const wishlist = this.getWishlist();
    
    // Check if item already exists
    const exists = wishlist.find(item => item.name === product.name);
    
    if (exists) {
      alert('⚠️ ' + product.name + ' is already in your wishlist!');
      return false;
    }
    
    wishlist.push({
      name: product.name,
      price: parseFloat(product.price),
      image: product.image
    });
    
    this.saveWishlist(wishlist);
    this.updateWishlistCount();
    return true;
  },

  // Remove item from wishlist
  removeFromWishlist(index) {
    const wishlist = this.getWishlist();
    wishlist.splice(index, 1);
    this.saveWishlist(wishlist);
    this.updateWishlistCount();
  },

  // Update wishlist count
  updateWishlistCount() {
    const wishlist = this.getWishlist();
    const wishlistBtn = document.querySelector('.wishlist_btn a');
    
    if (wishlistBtn) {
      // Remove existing count badge if present
      let badge = wishlistBtn.querySelector('.wishlist-count');
      if (!badge) {
        badge = document.createElement('span');
        badge.className = 'wishlist-count';
        badge.style.cssText = `
          position: absolute;
          top: -8px;
          right: -8px;
          background: #ff4444;
          color: white;
          border-radius: 50%;
          width: 20px;
          height: 20px;
          font-size: 12px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: bold;
        `;
        wishlistBtn.style.position = 'relative';
        wishlistBtn.appendChild(badge);
      }
      badge.textContent = wishlist.length;
      badge.style.display = wishlist.length > 0 ? 'flex' : 'none';
    }
  },

  // Add item to cart
  addItem(product) {
    const cart = this.getCart();
    
    // Check if item already exists
    const existingIndex = cart.findIndex(item => item.name === product.name);
    
    if (existingIndex > -1) {
      // Increase quantity if exists
      cart[existingIndex].quantity = (cart[existingIndex].quantity || 1) + 1;
    } else {
      // Add new item
      cart.push({
        name: product.name,
        price: parseFloat(product.price),
        image: product.image,
        quantity: 1
      });
    }
    
    this.saveCart(cart);
    this.updateUI();
    return true;
  },

  // Remove item from cart
  removeItem(index) {
    const cart = this.getCart();
    cart.splice(index, 1);
    this.saveCart(cart);
    this.updateUI();
  },

  // Calculate total
  getTotal() {
    const cart = this.getCart();
    return cart.reduce((sum, item) => sum + (item.price * (item.quantity || 1)), 0);
  },

  // Update all UI elements
  updateUI() {
    this.updateMiniCart();
    this.updateCartCount();
    this.updateCartTotal();
    this.updateWishlistCount();
  },

  // Update mini cart display
  updateMiniCart() {
    const cart = this.getCart();
    const miniCartItems = document.getElementById('mini-cart-items');
    
    if (!miniCartItems) return;

    miniCartItems.innerHTML = '';

    if (cart.length === 0) {
      miniCartItems.innerHTML = '<li style="color:white;text-align:center;padding:20px;">Your cart is empty</li>';
      return;
    }

    cart.forEach((item, index) => {
      const li = document.createElement('li');
      li.style.marginBottom = '15px';
      li.innerHTML = `
        <div style="display:flex; align-items:center; gap:10px; padding:10px; background:#444; border-radius:5px;">
          <img src="${item.image}" alt="${item.name}" width="60" style="border-radius:5px;">
          <div style="flex:1; color:white;">
            <h4 style="margin:0 0 5px 0; font-size:14px;">${item.name}</h4>
            <span style="color:#c69749;">Rs. ${item.price} x ${item.quantity}</span>
          </div>
          <button onclick="CartSystem.removeItem(${index})" style="background:none; border:none; color:#ff6b6b; cursor:pointer; font-size:20px;">
            <i class="ion-close"></i>
          </button>
        </div>
      `;
      miniCartItems.appendChild(li);
    });
  },

  // Update cart count badge
  updateCartCount() {
    const cart = this.getCart();
    const totalItems = cart.reduce((sum, item) => sum + (item.quantity || 1), 0);
    
    const countElements = document.querySelectorAll('.cart_quantity, #cart-count');
    countElements.forEach(el => {
      if (el) el.textContent = totalItems;
    });
  },

  // Update cart total
  updateCartTotal() {
    const total = this.getTotal();
    
    const totalElements = document.querySelectorAll('#mini-cart-total, .cart_text_quantity');
    totalElements.forEach(el => {
      if (el) {
        if (el.classList.contains('cart_text_quantity')) {
          el.textContent = `Rs. ${total.toFixed(0)}`;
        } else {
          el.textContent = total.toFixed(0);
        }
      }
    });
  },

  // Initialize cart system
  init() {
    // Update UI on load
    this.updateUI();

    // Setup add to cart buttons
    document.querySelectorAll('.add_to_cart_btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        
        const product = {
          name: btn.dataset.name,
          price: btn.dataset.price,
          image: btn.dataset.image
        };

        const added = this.addItem(product);
        
        if (added) {
          // Show success message
          alert(`✅ ${product.name} added to cart!`);
          
          // Optional: Open mini cart
          const miniCart = document.getElementById('mini-cart');
          if (miniCart) {
            miniCart.classList.add('active');
          }
        }
      });
    });

    // Setup wishlist buttons
    this.setupWishlistButtons();

    // Setup rating system
    this.setupRatings();

    // Setup Quick View modal - populate product data
    document.querySelectorAll('.open_modal_btn').forEach(btn => {
      btn.addEventListener('click', function() {
        const name = this.dataset.name;
        const price = this.dataset.price;
        const oldPrice = this.dataset.oldPrice;
        const image = this.dataset.image;

        const modal = document.getElementById('modal_box');
        if (modal) {
          modal.querySelector('.modal_title h2').textContent = name;
          modal.querySelector('.new_price').textContent = 'Rs. ' + price;
          if (modal.querySelector('.old_price')) {
            modal.querySelector('.old_price').textContent = 'Rs. ' + oldPrice;
          }
          modal.querySelector('.modal_tab_img img').src = image;

          // Store product data in modal for the Add to Cart button
          modal.dataset.productName = name;
          modal.dataset.productPrice = price;
          modal.dataset.productImage = image;
        }
      });
    });

    // Setup Add to Cart button INSIDE the modal
    const modalAddToCartBtn = document.querySelector('#modal_box .modal_add_to_cart button[type="submit"]');
    if (modalAddToCartBtn) {
      modalAddToCartBtn.addEventListener('click', (e) => {
        e.preventDefault();
        
        const modal = document.getElementById('modal_box');
        const quantity = modal.querySelector('input[type="number"]').value || 1;
        
        const product = {
          name: modal.dataset.productName,
          price: modal.dataset.productPrice,
          image: modal.dataset.productImage
        };

        // Add multiple times based on quantity
        for (let i = 0; i < quantity; i++) {
          this.addItem(product);
        }

        alert(`✅ ${quantity}x ${product.name} added to cart!`);
        
        // Close modal
        $('#modal_box').modal('hide');
        
        // Open mini cart
        const miniCart = document.getElementById('mini-cart');
        if (miniCart) {
          miniCart.classList.add('active');
        }
      });
    }

    // Setup View Cart buttons
    document.querySelectorAll('#view-cart, #view-cart-top').forEach(btn => {
      if (btn) {
        btn.addEventListener('click', (e) => {
          e.preventDefault();
          window.location.href = 'cart.html';
        });
      }
    });

    // Setup main Wishlist button (heart icon at top)
    const wishlistBtn = document.querySelector('.wishlist_btn a');
    if (wishlistBtn) {
      wishlistBtn.addEventListener('click', (e) => {
        e.preventDefault();
        window.location.href = 'wishlist.html';
      });
    } else {
      console.log('Wishlist button not found in header');
    }

    // Also check for alternative selectors
    const altWishlistBtn = document.querySelector('.middel_right .wishlist_btn a');
    if (altWishlistBtn) {
      altWishlistBtn.addEventListener('click', (e) => {
        e.preventDefault();
        window.location.href = 'wishlist.html';
      });
    }

    // Setup Checkout button
    
const checkoutBtn = document.getElementById('checkout');
if (checkoutBtn) {
  checkoutBtn.addEventListener('click', (e) => {
    e.preventDefault();
    window.location.href = "checkout.html";  // ✅ Opens checkout page
  });
}

  },

  // Setup wishlist buttons
  setupWishlistButtons() {
    console.log('🔍 Setting up wishlist buttons...');
    
    // Find all product cards
    const productCards = document.querySelectorAll('.single_product');
    console.log(`Found ${productCards.length} product cards`);
    
    productCards.forEach((productCard, cardIndex) => {
      // Find the wishlist button within this product card
      const wishlistLink = productCard.querySelector('.action_links a[title*="Wishlist"]') || 
                           productCard.querySelector('.action_links li:first-child a');
      
      if (!wishlistLink) {
        console.log(`No wishlist button found for product ${cardIndex}`);
        return;
      }
      
      console.log(`✅ Setting up wishlist for product ${cardIndex}`);
      
      wishlistLink.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        
        console.log('❤️ Wishlist button clicked');
        
        // Get product details
        const productNameEl = productCard.querySelector('h3 a');
        const priceEl = productCard.querySelector('.current_price');
        const imageEl = productCard.querySelector('.product_thumb img');
        
        if (!productNameEl || !priceEl || !imageEl) {
          console.error('❌ Missing product elements');
          alert('Error: Could not find product details');
          return;
        }
        
        const productName = productNameEl.textContent.trim();
        const priceText = priceEl.textContent.trim();
        const price = priceText.replace('Rs.', '').replace(/,/g, '').trim();
        const image = imageEl.src;
        
        const product = {
          name: productName,
          price: price,
          image: image
        };
        
        console.log('📦 Product details:', product);
        
        const added = this.addToWishlist(product);
        
        if (added) {
          // Change heart icon color
          const heartIcon = wishlistLink.querySelector('.ion-heart') || wishlistLink.querySelector('span');
          if (heartIcon) {
            wishlistLink.style.color = '#ff4444';
            heartIcon.style.color = '#ff4444';
          }
          
          console.log('✅ Added to wishlist successfully');
        }
      });
    });
    
    console.log('✅ Wishlist button setup complete');
  },

  // Setup rating system
  setupRatings() {
    document.querySelectorAll('.product_ratings ul').forEach(ratingContainer => {
      const stars = ratingContainer.querySelectorAll('li a');
      
      stars.forEach((star, index) => {
        star.addEventListener('click', (e) => {
          e.preventDefault();
          
          // Get product name for identification
          const productCard = star.closest('.single_product');
          const productName = productCard.querySelector('h3 a').textContent.trim();
          
          // Store rating in localStorage
          const ratings = JSON.parse(localStorage.getItem('productRatings')) || {};
          ratings[productName] = index + 1;
          localStorage.setItem('productRatings', JSON.stringify(ratings));
          
          // Update star display
          stars.forEach((s, i) => {
            const icon = s.querySelector('i');
            if (i <= index) {
              icon.className = 'ion-ios-star'; // Filled star
              s.style.color = '#ffc107';
            } else {
              icon.className = 'ion-ios-star-outline'; // Empty star
              s.style.color = '';
            }
          });
          
          alert(`⭐ You rated "${productName}" ${index + 1} star${index > 0 ? 's' : ''}!`);
        });
      });
      
      // Load saved rating if exists
      const productCard = ratingContainer.closest('.single_product');
      if (productCard) {
        const productName = productCard.querySelector('h3 a').textContent.trim();
        const ratings = JSON.parse(localStorage.getItem('productRatings')) || {};
        const savedRating = ratings[productName];
        
        if (savedRating) {
          stars.forEach((s, i) => {
            const icon = s.querySelector('i');
            if (i < savedRating) {
              icon.className = 'ion-ios-star';
              s.style.color = '#ffc107';
            }
          });
        }
      }
    });
  }
};

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  CartSystem.init();
});

// Make CartSystem globally accessible for inline onclick handlers
window.CartSystem = CartSystem;

document.getElementById("closeMiniCartBtn").addEventListener("click", function () {
    document.getElementById("mini-cart").style.display = "none";
});


